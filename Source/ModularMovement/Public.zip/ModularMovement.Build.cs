//Copyright Aurelion Iraj Mohtasham 2023. For distribution in epic store only 

using UnrealBuildTool;

public class ModularMovement : ModuleRules
{
	public ModularMovement(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		//PCHUsage = ModuleRules.PCHUsageMode.NoPCHs;
	//	bUseUnity = false;
		
        
		PublicIncludePaths.AddRange(
			new string[] {
				// ... add public include paths required here ...
			}
			);
				
		
		PrivateIncludePaths.AddRange(
			new string[] {
				// ... add other private include paths required here ...
			}
			);
			
		
		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core", "Engine", "AnimGraphRuntime", "ChaosVehiclesCore", "Niagara","AudioExtensions"
				// ... add other public dependencies that you statically link with here ...
			}
			);
			
		
		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"CoreUObject",
				"Engine",
				"Slate",
				"SlateCore","UMG", "Projects",	"Chaos", "ChaosVehiclesCore","PhysicsCore"
				// ... add private dependencies that you statically link with here ...	
			}
			);
		
		
		DynamicallyLoadedModuleNames.AddRange(
			new string[]
			{
				// ... add any modules that your module loads dynamically here ...
			}
			);
	}
}
